中央鼠标桌布局，适用于 Viola 新版 0.2.6 build 8。
本机已经应用。此包只含布局，不含程序。
恢复时退出 Viola 新版，将 character-layout.json 复制到 ~/Library/Application Support/ViolaDesktop-Preview/，然后重新打开应用。
完整程序可使用相邻的 Viola-macOS-arm64-v0.2.6-inward-parallel.zip；再应用本布局即可，不需要重新签名。
